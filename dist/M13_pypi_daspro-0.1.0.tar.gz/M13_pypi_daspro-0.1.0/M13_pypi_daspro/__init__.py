"""
pyexample.

An example python library.
"""

__version__ = "0.1.0"
__author__ = 'Azani Fattur Fadhika'
__credits__ = 'Politeknik Negeri Semarang'
